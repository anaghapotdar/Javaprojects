package com.springdata.springdata;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringdataApplicationTests {

	@Test
	void contextLoads() {
	}

}
