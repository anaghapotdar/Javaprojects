package com.springdata.springdata;  
import org.springframework.stereotype.Controller;  
import org.springframework.web.bind.annotation.RequestMapping;  
@Controller  
public class ControllerDemo   
{  
@RequestMapping("/")  
public String home()  
{  
return "Welcome to Spring Data Demo";  
}  
}  
